# 数据契约与本地后端通信

## 可保存的预设

contracts/preset.schema.json 使用 JSON Schema Draft 2020-12。默认样本逐字段沿用需求中的 JSON。根和各嵌套对象拒绝未声明字段。schema_version 固定为整数 1，采样步数与裁切量为整数，两个 denoise 落在闭区间 [0,1]。枚举由本机提供的字段保留为非空字符串，Schema 不硬编码自定义节点的可选值。参考图 path、workflow_id、部分模型、Scheduler 和 Hires 方法可为 null。为保持原始样本一致，description、ip_adapter.variant（类型提示）、reference.img2img_path（独立输入）为 v1 可选字段。Plus 的既有事实由已验证组合说明承载，确认加载器后才绑定。不能把 Plus 当成某个模型文件路径。单图约束是工作流与调度不变量，不依靠预设中可被改写的 batch 字段。

导入步骤为限制文件大小与嵌套深度，严格读 UTF-8 JSON，拒绝重复键、非有限数和未知版本，按本地打包的 Schema 校验，展示字段问题，然后生成新用户预设 ID。builtin 仅对随安装提供的受保护目录有效，导入值即使为 true 也不给内置权限。路径字段只是数据，不从预设读取启动命令、脚本、插件、在线引用或自定义表达式。导出稳定 UTF-8 JSON。新版本有明确迁移表时，保留原文件，迁移到副本并重新校验，较新或不可迁移版本不给导入覆盖。正式实现可用经过测试并随包离线提供的 Draft 2020-12 校验器。具体依赖与打包方式留到实现阶段。界面解析 seed 时保持整数精度，包括 2⁵³ 以上的值。

## 工作流绑定契约

contracts/workflow-mapping.draft.json 是无节点号的映射清单。status=unbound、空 targets、未知 capabilities 共同禁止提交。模板只能取自已授权的真实 API 格式图。含 nodes/links 的画布导出在识别后提示提供 API 格式，不执行自动转换。扫描节点类、已连接的上游端口与输出节点，标出正负 conditioning、采样及第二阶段、实际加载器、图像与模型路径。一个字段有多个候选时展示给用户确认。确认后的模板与映射分别版本化，并对原始字节计算 SHA-256。

| 映射属性 | 绑定后的内容与验证 |
|---|---|
| workflow_id / template_sha256 / mapping_revision | 共同标识不可变组合。签名失配、节点类变更或变体不匹配时重新核对 |
| capabilities | 标明此模板实际支持的 img2img、IP 开、IP 关、Hires、独立纯 txt2img。未知能力不可发布 |
| bindings[].source / role / when | 逻辑值取自预设或运行快照，when 限定 always/ip/img2img/hires/model_upscale，以及各输入真实裁切责任。仅检查激活分支 |
| targets[] | 每个目标包含 node_id（字符串）、expected_class、input_key、expected_type、写入策略和允许的值来源。路径必须已存在。目标可多于一个，必须说明为何同值作用于多个输入 |
| kind | literal 只换常量。resolved_file 使用后端真实名字。uploaded_image 使用上传回执 token。seed_plan 按节点。invariant 校验已绑定值或固定图结构。capability_or_literal 支持固定拓扑证明。verified_route 选择已核实的图变体或既有开关 |
| stages / output_nodes | 记录经过核对的基础/Hires 节点集合及最终输出节点。中间预览不能混入最终图库 |
| reference_relationship / reference_crop_owners | 枚举 shared / separate，分别为 IP、img2img 设置 studio / workflow / none。表明取哪份原图、哪一分支要裁、裁一次的位置 |
| seed_plan / verified_dimensions | 每个采样器的 seed 来源、是否共享/继承、实际有效范围。阶段尺寸、取整、放大位置和验证基准。未知时不得把 1024 推论成某个固定宽高 |

**绑定值的优先顺序。** 有明确用户值时必须能无歧义注入或与固定值相符。空值可由绑定契约明确允许的、已核实的固定模板常量解析，注明来源。固定模式或图结构可以作为能力证据，不需凭空填入不存在的字段。没有证据的必需项列入缺失清单，禁止把 null 发送给要求标量的节点。预设保持原样，任务快照额外保存“有效配置及来源”。LoRA 若有 model_strength 与 clip_strength 等不同实际输入，分别核对原模板值，不默认都写成 0.85。CFG、Steps、sampler、scheduler 同理，保留第二阶段原有设置。若内置默认与真实模板冲突，显示两边的值，暂停绑定，保留原件。

**输入角色与裁切。** shared 只意味着同源，两个分支可用不同裁切策略。separate 必须明确各自文件。若原图已在节点中裁切，则上传冻结原图，只注入真实裁切节点的对应数值。若由 Studio 裁切，输出独名内存副本并核对下游没有第二次等效裁切。若模板依赖其他裁切、缩放、蒙版、色彩空间或 EXIF 方向处理，预览和输入按实测顺序一致，无法证明就暂停绑定。显式关闭 IP 时仍保留活跃 img2img 输入与 0.65。纯 txt2img 必须有经确认的独立图路径。不用 img2img denoise 的模板不强填该值。不得通过权重置零模拟解除 IP 的拓扑依赖。

**提交次序。** 入队先冻结逻辑值、所有实际种子、模板版本、输入副本并做准备检查。派发前复验后端、能力、单任务执行位及冻结资源。深拷贝对应版本的模板，将已有数值写入允许的输入。需要上传的副本使用回执 token 填入任务图，保留回执附录。检查节点、必需常量、边的来源及端口、选项/范围、单图性与结果节点，比较改动路径白名单并复算模板摘要，随后持久化提交意图。每个实际采样器的种子都应可解释：若图证实共享才共享，若第二阶段独立或固定则按原方案保存。禁止自动重建图或猜测未解析输入。最终以 /prompt 的服务端校验为准，未发现通用无副作用的校验接口时不以试提交充当校验。

## 规则文件

guardrails.json 的 all 是与条件。path 为固定根下的 JSON Pointer，op 只支持 eq、ne、gt，value 为普通数据，比较类型严格。载入时校验版本、路径与操作符白名单。禁止 eval。事实由验证模块产生，不接受用户预设自报事实。布尔事实是 true/false/未知，对阻断条件 ne true，未知也成立。不适用的分支从必需集合剔除后返回 true。质量类仅在能确认适用时展示，未知不冒称经验适用。每条阻断另附实际缺失路径、节点或文件名。点击可跳转控件。

| 派生事实 | 如何取得 |
|---|---|
| quality_profile_matches | 模型组合、IP Plus 系列和经确认的模板谱系匹配这份本机经验。不按预设名判断。原型专设固定组合演示 |
| backend_ready / mapping_ready | 当前回环 HTTP 返回有效 ComfyUI 数据。模板与映射摘要、全部激活角色、类与字段通过检查 |
| required_values_resolved / node_constraints_valid | 从预设、已验证固定值与运行时绑定解析。分支必须拥有有效 Scheduler、输入、作用模型等，检查实际节点约束、seed 和枚举 |
| required_assets_available / active_crops_valid | 工作流依赖的模型在后端节点清单中可选择或经本地只读核实。图像可读可解码。每个需要裁切的输入 H−top−bottom>0 |
| single_image_graph / snapshot_writable | 实际分支为单图，Batch Size 恒 1。持久化和输入副本可用 |
| hires_active / size_outside_verified | 图结构证明该分支执行 Hires。基于已核对的尺寸管线与本机验证记录判断。信息不足时前端说明未知 |

0.65 和 0.12 是严格大于的边界。linear 的文字匹配后端实际枚举。质量警告不改参、不阻断。模型缺失、裁切高度等于零、离线、未绑定等分别阻断。IP 关闭后这三条 IP 警告均失效，仍按 img2img 和 Hires 活跃需求校验。

## HTTP / WS 协议

下表为设计基线，需与本机版本的响应样本核对。地址默认 http://127.0.0.1:8188。WebSocket 使用对应的 ws 回环地址。不跟随跳往非回环地址的重定向。静态原型没有连接路径。

| 接口 | 方向及数据 | 响应、失败与重试 |
|---|---|---|
| GET /system_stats | 健康检查。约 2 秒一次、可配，单请求在途 | 成功且结构识别后在线。设备字段存在且单位明确才显示显存。HTTP 200 的普通 HTML 不算就绪 |
| GET /object_info 或 /object_info/{node_class} | 取真实类型、枚举、允许范围及模型列表 | 缓存能力快照，手动刷新或后端重连后失效重查。能力尚未核实时禁用相应操作 |
| POST /upload/image | multipart 的 image 部分，Studio 独立前缀 + UUID + 真实格式后缀，按本机能力使用独立子目录并关闭覆盖 | 保存实际响应的 name、subfolder、type 等。按实际加载器格式形成相对 token，不传任意绝对路径。超时保留可能存在的孤立输入，要求重新核对 |
| POST /prompt | JSON 包含 prompt（任务图）、client_id（对应 WS clientId）。只有本机验证支持时添加可回读的 UUID 元数据 | 持久化 prompt_id。节点校验错误展示节点名与字段。网络超时/不明确的 5xx 进入待确认，不能盲重发 |
| GET /queue | 查询 running 与 pending，按本机结构提取 prompt_id、可辨别的归属 | 轮询与重连对账。仅显示外部占用。对每个活动任务分别核对 |
| POST /queue | 仅在该版本已确认能按指定 ID 删除本软件 pending 项时，提交单项删除请求 | 删除前后核对 ID，已转 running 时收回删除操作。清空本地等待队列无需后端请求 |
| GET /history/{prompt_id} 或 GET /history | 取状态、执行消息及输出描述，可按能力回退到有界读取 | 区分成功、中断、失败、尚未写入和被清理。先保留终态证据，单次空记录延迟重查 |
| GET /view | 用响应给出的 filename、subfolder、type 编码查询。适用于后端提供的输出 | 优先索引核实的本机文件。只在需查看/缩略时读取。无法解析本地路径仍可通过 /view 预览，打开目录置灰。限制解析结果位于已授权输出根 |
| POST /interrupt | 仅由用户确认触发。先核对本软件运行任务与目标版本是否支持限定目标 | 若只有全局中断，提示可能影响其他客户端。并用环境或明确的独占运行条件证明不会中断他人，否则禁用。一次 GET /queue 不能消除竞态。仅有 HTTP 成功也不等于已中断 |
| WS /ws?clientId=… | 客户端只监听。连接身份与 /prompt 一致 | 解析 status、execution_start、executing、progress、execution_cached、executed、execution_success/error/interrupted 等可用事件。二进制仅解码已核实格式 |

事件处理以 prompt_id + 已验证的节点映射隔离任务。缺少 ID 的进度/预览只有在协议和独占关联可证明时才使用。progress 的 value/max 是节点进度，max≤0 显示不定进度。缓存命中单独说明。executed 可能仅是节点 UI 输出。executing 的 node=null 可触发查历史。未知二进制帧直接忽略，不回放上张结果冒充实时预览。事件晚到或乱序不能让终态退回执行中。

### 后端启动与恢复

1. 用户点击启动，取得本地启动锁并再次探测。已在线或本实例仍在启动时复用状态。端口被其他进程占用则提示冲突。识别已有未就绪的便携实例或无法排除其正在启动时显示「启动中/待核对」，避免重复拉起。
2. 正式版使用非 shell 的独立进程参数调用 Windows wscript.exe 与 E:\ComfyUI\_download\run_silent.vbs，避免控制台窗口。保留既有工作目录约定。确有需要时才启用经确认的 E:\ComfyUI\_download\launch_hidden.ps1 分支。脚本缺失或执行策略拒绝时显示路径与原始错误。现有脚本负责 --lowvram 等启动参数。
3. 健康探测约 2 秒。启动给出单次等待截止时间，超时保留「查看详情/刷新」，不自动反复启动。HTTP 与 WS 的健康分别显示。WS 断开采用约 1、2、4、8、16、30 秒封顶的退避加少量抖动，恢复后重置。
4. 先进入同步屏障，缓冲新 WS 事件，同时读 /queue 和活动 ID 的 /history。按证据恢复状态，再按顺序合并事件。曾在本地落盘的发送意图也需核对。所有活动记录都已明确后才恢复派发。

官方接口基线见 [ComfyUI Server Routes](https://docs.comfy.org/development/comfyui-server/comms_routes)、[Server Messages](https://docs.comfy.org/development/comfyui-server/comms_messages) 和 [官方 WebSocket 客户端示例](https://github.com/Comfy-Org/ComfyUI/blob/master/script_examples/websockets_api_example.py)。Schema 版本见 [JSON Schema Draft 2020-12](https://json-schema.org/draft/2020-12)。

