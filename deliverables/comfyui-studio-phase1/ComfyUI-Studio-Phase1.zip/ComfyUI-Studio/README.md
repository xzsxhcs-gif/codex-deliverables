# ComfyUI Studio ｜ 第一阶段设计交付

**手机上可先看 Studio-Desktop.png。电脑上从 Studio-Preview.html 开始。** 双击即可离线查看主界面和六个页面。右上角可切换「离线草稿」「运行示例」「首次打开」。试着把 IP 权重从 0.60 调到 0.66，观察橙色标记和本组合警告，再关闭 IP，检查 img2img denoise 仍可编辑。可选本地图片仅在页面内存里预览。样张为本设计制作的风景插画。

| 想核对的内容 | 打开的文件 |
|---|---|
| 软件如何分层、如何保护模型与文件、如何恢复任务 | design/Architecture.md |
| 六页布局、全部控件、建议范围、键盘和窄屏规则 | design/Interaction.md |
| Workflow 绑定、参考图与种子、HTTP/WS 接口、提交校验 | design/Integration.md |
| 预设存储格式与原始默认值 | contracts/preset.schema.json、contracts/verified-default.json |
| 警告条件、阻断规则及未绑定映射 | contracts/guardrails.json、contracts/workflow-mapping.draft.json |
| 已做检查、尚待真机验收的条目、下一阶段所需信息 | design/Review.md |

静态原型是交互设计载体。正式产品采用 Python、PySide6 和原生 Qt Widgets，可独立使用。已验证数值来自你的既有出图实验。这里以初次使用、还未绑定真实工作流的状态交付。你确认本阶段后，下一步才是只读分析真实 API Workflow。

