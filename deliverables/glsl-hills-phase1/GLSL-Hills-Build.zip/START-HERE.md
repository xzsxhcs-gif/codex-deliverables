# GLSL Hills 成品构建

GLSL-Hills.html 为单文件版本，已内联应用代码、样式、字体和第三方许可。允许本地脚本的浏览器可直接打开；若浏览器策略限制本地文件，请使用静态 HTTP 服务。

在解压目录执行 `python -m http.server 8080`，然后打开 `http://localhost:8080/GLSL-Hills.html`。标准部署使用 index.html、assets/ 和 favicon.svg，可放在静态网站的子目录中。

需要支持 WebGL 2 的现代浏览器。无需 API 密钥、账户、在线字体或付费服务。实体手机和 Safari 尚未实机验证。当前验收环境的 file:// 导航被管理员禁止，因此单文件验收通过 HTTP 执行。
